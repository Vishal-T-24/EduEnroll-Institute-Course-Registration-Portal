package com.example.MainProject.Controllers;

import com.example.MainProject.Models.Courses;
import com.example.MainProject.Models.Enrolled_Students;
import com.example.MainProject.Services.Service1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
@RestController
@CrossOrigin(origins = "*")
public class Controller1 {

    @Autowired
    Service1 se;

    @GetMapping("/courses")
    public List<Courses> getAllcourses(){
        return se.getAllcourse();
    }

    @PostMapping("/student_details")
    public String addStudent(@RequestParam("name") String name,
                             @RequestParam("email") String email,
                             @RequestParam("courseselected") String Course){
        se.addStudent(name,email,Course);
        return "Congrats "+name+"! you're Successfully Registered for "+Course+" Bootcamp!!!";
    }

    @GetMapping("/enrolledstudents")
    public List<Enrolled_Students> getAllstudents(){
        return se.getAllstudents();
    }
}
