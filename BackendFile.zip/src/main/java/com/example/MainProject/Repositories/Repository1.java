package com.example.MainProject.Repositories;

import com.example.MainProject.Models.Courses;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Repository1 extends JpaRepository<Courses,Integer> {

}
