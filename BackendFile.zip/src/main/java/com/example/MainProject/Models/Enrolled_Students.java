package com.example.MainProject.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;

@Entity
@Data

public class Enrolled_Students {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private String email;
    private String courseselected;

    public Enrolled_Students(){

    }

    public Enrolled_Students(String name,String email,String courseselected){
        this.name=name;
        this.email=email;
        this.courseselected=courseselected;
    }
}
