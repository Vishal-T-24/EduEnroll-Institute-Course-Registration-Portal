package com.example.MainProject.Services;

import com.example.MainProject.Models.Courses;
import com.example.MainProject.Models.Enrolled_Students;
import com.example.MainProject.Repositories.Repository1;
import com.example.MainProject.Repositories.Repository2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Service1 {

    @Autowired
    Repository1 r1;

    @Autowired
    Repository2 r2;

    public List<Courses> getAllcourse() {
       return r1.findAll();

    }


    public void addStudent(Enrolled_Students es) {
        r2.save(es);
    }

    public List<Enrolled_Students> getAllstudents() {

        return r2.findAll();
    }

    public void addStudent(String name, String email, String course) {
        Enrolled_Students es=new Enrolled_Students(name,email,course);

        r2.save(es);
    }
}
