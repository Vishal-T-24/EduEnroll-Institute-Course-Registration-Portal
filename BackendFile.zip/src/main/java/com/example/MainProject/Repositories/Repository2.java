package com.example.MainProject.Repositories;

import com.example.MainProject.Models.Enrolled_Students;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Repository2 extends JpaRepository<Enrolled_Students,Integer> {
}
