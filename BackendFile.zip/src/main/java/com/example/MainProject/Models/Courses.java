package com.example.MainProject.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Courses {

    @Id
    private int Cid;
    private String Cname;
    private String trainer;
    private int Durationinweeks;
}
